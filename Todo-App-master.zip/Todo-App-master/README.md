# Todo-App
  A simple todo app example in Flutterusman18/twitter-fab-animation-in-android-544f2de80e86)

## Screenshots

<img height=550 width=275 src="https://github.com/usman18/Todo-App/blob/master/Screenshots/Todo1.JPG"><img height=550 width=275 src="https://github.com/usman18/Todo-App/blob/master/Screenshots/Todo2.JPG" hspace=24/><img height=550 width=275 src="https://github.com/usman18/Todo-App/blob/master/Screenshots/Todo3.JPG"/> 


## Contributions
Contributions are always welcome. Please fork this repository and contribute using pull requests. The pull requests will be thoroughly assessed and if found significant will be accepted.

## Catch me at

- [Instagram](https://www.instagram.com/usman__khan18/)
- [Twitter](https://www.twitter.com/khan_usman_18)
- [Medium](https://medium.com/@usman18)
- [LinkedIn](https://www.linkedin.com/in/usman-khan-7b04b1138)
- [Github](https://github.com/usman18)

My email : uk32971@gmail.com
